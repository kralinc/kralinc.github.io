//Author: Liam Andrade
//Purpose: Consolidate the locations of class definitions and constant variables in the program.

//Vector2 Definitions
function Vector2 (x, y) 
{
    this.x = x;
    this.y = y;
}

Vector2.prototype.add = function (otherVector) 
{
    this.x += otherVector.x;
    this.y += otherVector.y;
};

Vector2.prototype.times = function (factor)
{
    this.x *= factor;
    this.y *= factor;
}

Vector2.prototype.mult = function (vector, factor) {
    return new Vector2 (vector.x * factor, vector.y * factor);
}

Vector2.prototype.copy = function () {
    return new Vector2(this.x, this.y);
}

Vector2.prototype.ZERO = new Vector2(0, 0);

const BULLETSIZE = 3;

class Bullet 
{
    constructor (direction, position, velocity, acceleration, id) 
    {
        this.dir = direction;
        //The holy trinity
        this.pos = position;
        this.vel = velocity;
        this.acc = acceleration;
        this.id = id;
        this.size = new Vector2 (BULLETSIZE, BULLETSIZE);
    }
}

Bullet.prototype.isOverlapping = checkOverlap;


class Pattern {
    //d means delta
    constructor (numBullets, dir, ddir, pos, dpos, vel, dvel, acc, dacc, delay, ddelay)
    {
        this.numBullets = numBullets;
        //In radians
        this.dir = dir;
        this.ddir = ddir;
        //As a % of screenspace per frame
        this.pos = pos;
        this.dpos = dpos;
        //As a % of screenspace per frame
        this.vel = vel;
        this.dvel = dvel;
        //As a % of screenspace per frame
        this.acc = acc;
        this.dacc = dacc;
        //Milliseconds
        this.delay = delay;
        this.ddelay = ddelay;
        this.iterator = 1;
    }
    
    //Launch a projectile
    fire(index) 
    {
        //Return nothing if there are no more bullets to be fired
        if (this.iterator > this.numBullets) {
            return null;
        }
        let bullet = new Bullet(this.dir, this.pos.copy(), this.vel, this.acc, index);
        this.dir += this.ddir;
        this.pos.add(this.dpos);
        this.vel += this.dvel;
        this.acc += this.dacc;
        this.delay += this.ddelay;
        
        this.iterator++;
        
        return bullet;
    }
    
    copy() {
        return new Pattern(this.numBullets, this.dir, this.ddir, this.pos.copy(), this.dpos.copy(), this.vel, this.dvel, this.acc, this.dacc, this.delay, this.ddelay);
    }
}

//The player object
function Player(health, pos, vel) {
    this.health = health;
    this.pos = pos;
    this.vel = vel;
    this.input = new Vector2(0,0);
    this.size = new Vector2(2,2);
    this.left = 0;
    this.right = 0;
    this.up = 0;
    this.down = 0;
}

//Check if 2 boxes are overlapping
function checkOverlap(other) 
{
    
    //I tried to make this algorithm work for any rectangles but this thing copied verbatim from online didn't work
    //Leaving this here to show that I tried :(
//    //Rectangles will be represented by their bottom-left and top-right corners.
//    let thisBottomLeft = new Vector2 (this.pos.x, this.pos.y + this.size.y);
//    let thisTopRight   = new Vector2 (this.pos.x + this.size.x, this.pos.y);
//    
//    let otherBottomLeft = new Vector2 (other.pos.x, other.pos.y + other.size.y);
//    let otherTopRight = new Vector2 (other.pos.x + other.size.x, other.pos.y);
//    
//    //The only times that the rectangles will not overlap will be when 
//    //1. One of the two rectangles is above the top edge of the other rectangle
//    //2. One of the two rectangles is on the left side of the left edge of the other rectangle
//    return (!
//           ((otherTopRight.x <= thisBottomLeft.x) ||
//           (otherBottomLeft.x >= thisTopRight.x) ||
//           (otherTopRight.y <= thisBottomLeft.y) ||
//           (otherBottomLeft.y >= thisTopRight.y)));
    
    //Takes advantage of the fact that the player and the bullets are the same shape
    //Finds the distance between the 2 boxes. if the distance between them is less than their diameter, they overlap.
    let thisCenter = new Vector2(this.pos.x + this.size.x / 2, this.pos.y + this.size.y / 2);
    let otherCenter = new Vector2(other.pos.x + other.size.x / 2, other.pos.y + other.size.y / 2);
    
    let distX = (otherCenter.x - thisCenter.x) * (otherCenter.x - thisCenter.x);
    let distY = (otherCenter.y - thisCenter.y) * (otherCenter.y - thisCenter.y);
    let distance = Math.sqrt(distX + distY);
    
    return (distance < (this.size.x/2 + other.size.x/2));
    
}

