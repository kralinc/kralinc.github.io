//Collects all of the bullet patterns in one place

//numBullets, direction, position, velocity, acceleration, delay
const PATTERN_HEXAGON = new Pattern (6, 
                                     0, Math.PI / 3, 
                                     new Vector2(50, 50), Vector2.prototype.ZERO, 
                                     0.3, 0, 
                                     0, 0, 
                                     200, 0);

const PATTERN_OCTAGON = new Pattern (8, 
                                     Math.PI / 4, Math.PI / 4, 
                                     new Vector2(50, 50), Vector2.prototype.ZERO, 
                                     0.31, 0, 
                                     0, 0, 
                                     170, 0);

const PATTERN_REVERSE_OCTAGON = new Pattern (8, 
                                     Math.PI / 4, -Math.PI / 4, 
                                     new Vector2(50, 50), Vector2.prototype.ZERO, 
                                     0.31, 0, 
                                     0, 0, 
                                     170, 0);

const PATTERN_RAIN = new Pattern (10,
                                 Math.PI / 2, 0,
                                 new Vector2(0,0), new Vector2(10,0),
                                 0.3, 0.01,
                                 0.005, 0,
                                 200, 0);

const PATTERN_RAIN_SHIFT = new Pattern (10,
                                 Math.PI / 2, 0,
                                 new Vector2(5,0), new Vector2(10,0),
                                 0.3, 0.01,
                                 0.005, 0,
                                 200, 0);

const PATTERN_SMOKE = new Pattern (10,
                                 3 * Math.PI / 2, 0,
                                 new Vector2(100-BULLETSIZE,100), new Vector2(-10,0),
                                 0.3, 0.01,
                                 0.005, 0,
                                 200, 0);

const PATTERN_SMOKE_SHIFT = new Pattern (10,
                                 3 * Math.PI / 2, 0,
                                 new Vector2(BULLETSIZE,100), new Vector2(10,0),
                                 0.3, 0.01,
                                 0.005, 0,
                                 200, 0);

const PATTERN_SWORLY = new Pattern (15,
                                   2 * Math.PI / 2, Math.PI / 6,
                                    new Vector2(50, 50), Vector2.prototype.ZERO,
                                   0.35, 0.01,
                                   0.009, 0.001,
                                   190, 0);

const PATTERN_SWORLY_REVERSE = new Pattern (15,
                                   2.5 * Math.PI / 2, -Math.PI / 7,
                                    new Vector2(50, 50), Vector2.prototype.ZERO,
                                   0.35, 0.01,
                                   0.009, 0.001,
                                   190, 0);

const PATTERN_FLIPPED_HEXAGON = new Pattern (6, 
                                     Math.PI / 6, Math.PI / 3, 
                                     new Vector2(50, 50), Vector2.prototype.ZERO, 
                                     0.34, 0, 
                                     0, 0, 
                                     200, 0);

const PATTERN_HEXASHOTGUN = new Pattern (6, 
                                     Math.PI / 4.2, Math.PI / 3, 
                                     new Vector2(50, 50), Vector2.prototype.ZERO, 
                                     0.34, 0, 
                                     0.005, 0, 
                                     1, 0);

const PATTERN_HEXASHOTGUN_ROTATED = new Pattern (6, 
                                     Math.PI / 8, Math.PI / 3, 
                                     new Vector2(50, 50), Vector2.prototype.ZERO, 
                                     0.34, 0, 
                                     0.005, 0, 
                                     1, 0);

const PATTERN_OCTASHOTGUN = new Pattern (8, 
                                    Math.PI / 7, Math.PI / 4, 
                                    new Vector2(50, 50), Vector2.prototype.ZERO, 
                                    0.31, 0, 
                                    0, 0, 
                                    1, 0);

const PATTERN_OCTASHOTGUN_ROTATED = new Pattern (8, 
                                    Math.PI / 10, Math.PI / 4, 
                                    new Vector2(50, 50), Vector2.prototype.ZERO, 
                                    0.31, 0, 
                                    0, 0, 
                                    1, 0);

const PATTERN_REVERSE_OCTAGON_ROTATE = new Pattern (8, 
                                     Math.PI / 16, -Math.PI / 4, 
                                     new Vector2(50, 50), Vector2.prototype.ZERO, 
                                     0.31, 0, 
                                     0, 0, 
                                     170, 0);

const PATTERN_DIAMONDBOUNCE = new Pattern (4,
                                           Math.PI / 4, Math.PI / 2,
                                           new Vector2(50,50), Vector2.prototype.ZERO,
                                           1.1, 0,
                                           -0.0085, 0,
                                           5, 0);

const PATTERN_NOMERCY = new Pattern (50,
                                    0, 0.126,
                                     new Vector2(50,50), Vector2.prototype.ZERO,
                                     0.32, 0,
                                     0, 0,
                                     500, 0);


//====Hell patterns ====

const HELL_NOMERCY = new Pattern (50,
                                0, 0.126,
                                 new Vector2(50,50), Vector2.prototype.ZERO,
                                 0.35, 0,
                                 0.001, 0,
                                 100, 0);

const HELL_DIAMONDBOUNCE = new Pattern (4,
                                       0, Math.PI / 2,
                                       new Vector2(50,50), Vector2.prototype.ZERO,
                                       1.5, 0,
                                       -0.0225, 0,
                                       5, 0);

const HELL_DIAMONDBOUNCE_2 = new Pattern (4,
                                       Math.PI / 4, Math.PI / 2,
                                       new Vector2(50,50), Vector2.prototype.ZERO,
                                       1.5, 0,
                                       -0.0159, 0,
                                       5, 0);

const HELL_DODECAGON = new Pattern (12, 
                                Math.PI / 12, 0.52359, 
                                new Vector2(50, 50), Vector2.prototype.ZERO, 
                                0.35, 0, 
                                0.001, 0, 
                                100, 0);

const HELL_DODECASHOTGUN = new Pattern (12, 
                                Math.PI / 5, 0.52359, 
                                new Vector2(50, 50), Vector2.prototype.ZERO, 
                                0.33, 0, 
                                0.003, 0, 
                                1, 0);

const HELL_RAIN = new Pattern (11,
                                 Math.PI / 2, 0,
                                 new Vector2(0,0), new Vector2(9,0),
                                 0.39, 0.01,
                                 0.008, 0,
                                 50, 0);